from app.tools.orders_api import get_order
from app.tools.product_catalog_api import get_product_category
from app.utils.logger import logger


def order_lookup_node(state):

    logger.info("OrderLookup node started")

    order_id = state["ticket"].get("order_id")

    if not order_id:
        state["decision"] = "INVALID_ORDER"
        state["status"] = "PENDING_HUMAN_REVIEW"
        state["reasoning"] = "Order ID not provided."
        return state

    order = get_order(order_id)

    state["order"] = order

    logger.info(f"order result: {order}")

    if not order:
        state["decision"] = "INVALID_ORDER"
        state["status"] = "PENDING_HUMAN_REVIEW"
        state["reasoning"] = "Order ID not found in order database."
        return state

    # -----------------------------
    # Get category from catalog
    # -----------------------------

    sku = order.get("sku")

    category = get_product_category(sku)

    state["category"] = category

    logger.info(f"Product category: {category}")

    return state