import pandas as pd
import os
from app.config import DATA_PATH
from app.utils.logger import logger




# -----------------------------
# Orders Data
# -----------------------------
orders_df = pd.read_csv(f"{DATA_PATH}/orders.csv")

logger.info(f"Loaded orders: {len(orders_df)}")


# -----------------------------
# Fraud Data
# -----------------------------
fraud_df = pd.read_csv(f"{DATA_PATH}/fraud_markers.csv")

logger.info(f"Loaded fraud records: {len(fraud_df)}")


# -----------------------------
# Product Catalog
# -----------------------------
product_catalog_df = pd.read_csv(f"{DATA_PATH}/product_catalog.csv")

logger.info(f"Loaded product catalog: {len(product_catalog_df)}")


