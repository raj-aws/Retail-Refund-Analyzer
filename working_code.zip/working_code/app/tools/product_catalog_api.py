from app.ingestion.csv_loader import product_catalog_df
from app.utils.logger import logger


def get_product_category(sku):

    logger.info(f"Looking up category for SKU: {sku}")

    result = product_catalog_df[product_catalog_df["sku"] == sku]

    if result.empty:
        logger.warning("SKU not found in product catalog")
        return None

    row = result.iloc[0]

    category = row.get("category")

    logger.info(f"Category found: {category}")

    return category