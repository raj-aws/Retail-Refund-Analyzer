import chromadb
from app.config import CHROMA_DIR
from app.utils.logger import logger


client = chromadb.PersistentClient(path=CHROMA_DIR)

collection = client.get_or_create_collection(
    name="policy_docs"
)


def get_relevant_docs(query, category=None, k=5):

    logger.info(f"Retrieval query: {query}")
    logger.info(f"Category filter: {category}")

    if category:
        results = collection.query(
            query_texts=[query],
            where={"policy_type": category},
            n_results=k
        )
    else:
        results = collection.query(
            query_texts=[query],
            n_results=k
        )

    documents = results.get("documents", [[]])[0]
    metadatas = results.get("metadatas", [[]])[0]

    docs = []

    for content, metadata in zip(documents, metadatas):

        docs.append({
            "content": content,
            "metadata": metadata
        })

    return docs