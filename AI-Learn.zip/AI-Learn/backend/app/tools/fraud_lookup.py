from app.ingestion.csv_loader import fraud_df
from app.utils.logger import logger


def get_fraud(customer_id):
    logger.info("Fraud lookup started")

    result = fraud_df[fraud_df["customer_id"] == customer_id]

    if result.empty:
        logger.info("Customer not found in fraud table. Using default low risk.")
        return {"score": 0.1, "flags": []}

    row = result.iloc[0]

    try:
        raw_score = float(row["score"])
    except Exception:
        logger.warning("Invalid fraud score format. Defaulting to 0.1")
        raw_score = 0.1

    logger.info(f"Raw fraud score from CSV: {raw_score}")

    # Normalize if score looks like percentage (e.g., 12 → 0.12)
    if raw_score > 1:
        raw_score = raw_score / 100.0
        logger.info(f"Normalized fraud score: {raw_score}")

    return {
        "score": raw_score,
        "flags": row["flags"]
    }