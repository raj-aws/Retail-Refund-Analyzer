import random
from app.utils.logger import logger

class PaymentTimeout(Exception):
    pass

def create_refund(amount):
    logger.info("Mock Payment API called")

    # 🔴 Force failure for learning
    raise PaymentTimeout("Simulated payment timeout")