from app.ingestion.csv_loader import orders_df

def get_order(order_id):
    result = orders_df[orders_df["order_id"] == order_id]
    if result.empty:
        return None
    return result.iloc[0].to_dict()