import json
from app.utils.logger import logger


def extract_json_from_response(response: str):
    """
    Extract first valid JSON object from LLM output safely.
    Ignores trailing explanations.
    """

    start = response.find("{")
    if start == -1:
        logger.error("No JSON object found in LLM response")
        logger.error(f"Raw response:\n{response}")
        return None

    brace_count = 0
    end = None

    for i in range(start, len(response)):
        if response[i] == "{":
            brace_count += 1
        elif response[i] == "}":
            brace_count -= 1
            if brace_count == 0:
                end = i + 1
                break

    if end is None:
        logger.error("Could not find complete JSON object")
        logger.error(f"Raw response:\n{response}")
        return None

    json_str = response[start:end]

    try:
        return json.loads(json_str)
    except Exception as e:
        logger.error(f"JSON parsing failed: {e}")
        logger.error(f"Extracted JSON:\n{json_str}")
        return None