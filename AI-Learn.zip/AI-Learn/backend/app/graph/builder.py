from langgraph.graph import StateGraph, END
from app.graph.state import AgentState

from app.nodes.intent import intent_node
from app.nodes.order_lookup import order_lookup_node
from app.nodes.fraud_lookup import fraud_lookup_node
from app.nodes.retrieval import retrieval_node
from app.nodes.policy_enforcement import policy_enforcement_node
from app.nodes.confidence import confidence_node
from app.nodes.safety import safety_node
from app.nodes.hitl import hitl_node
from app.nodes.action import action_node


def build_graph():

    workflow = StateGraph(AgentState)

    # -----------------------
    # Register Nodes
    # -----------------------
    workflow.add_node("intent", intent_node)
    workflow.add_node("order", order_lookup_node)
    workflow.add_node("fraud", fraud_lookup_node)
    workflow.add_node("retrieve", retrieval_node)
    workflow.add_node("enforce", policy_enforcement_node)
    workflow.add_node("confidence", confidence_node)
    workflow.add_node("safety", safety_node)
    workflow.add_node("hitl", hitl_node)
    workflow.add_node("action", action_node)

    # -----------------------
    # Entry Point
    # -----------------------
    workflow.set_entry_point("intent")

    # -----------------------
    # Linear Flow
    # -----------------------
    workflow.add_edge("intent", "order")
    workflow.add_edge("order", "fraud")
    workflow.add_edge("fraud", "retrieve")
    workflow.add_edge("retrieve", "enforce")
    workflow.add_edge("enforce", "confidence")

    # Always go to safety after confidence
    workflow.add_edge("confidence", "safety")

    # -----------------------
    # Conditional Routing AFTER safety
    # -----------------------
    workflow.add_conditional_edges(
        "safety",
        lambda state: "hitl" if state.get("status") == "PENDING_HUMAN_REVIEW" else "action",
        {
            "hitl": "hitl",
            "action": "action"
        }
    )

    # -----------------------
    # Final Edges
    # -----------------------
    workflow.add_edge("hitl", "action")
    workflow.add_edge("action", END)

    return workflow.compile()