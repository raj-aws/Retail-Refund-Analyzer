from fastapi import FastAPI
import uuid

from app.graph.builder import build_graph
from app.db.database import SessionLocal
from app.db.models import Ticket

app = FastAPI()
graph = build_graph()

@app.get("/")
def root():
    return {"message": "OmniRetail Copilot Running"}

@app.post("/process")
def process(ticket: dict):

    ticket["ticket_id"] = str(uuid.uuid4())

    result = graph.invoke({
        "ticket": ticket,
        "order": None,
        "fraud": {},
        "retrieved_docs": [],
        "reasoning": "",
        "confidence": 0,
        "status": ""
    })

    db = SessionLocal()
    db_ticket = Ticket(
        id=ticket["ticket_id"],
        status=result["status"],
        reasoning=result["reasoning"],
        confidence=result["confidence"]
    )
    db.add(db_ticket)
    db.commit()
    db.close()

    return result