from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, String, Float, Text, DateTime
from datetime import datetime


Base = declarative_base()

class Ticket(Base):
    __tablename__ = "tickets"

    id = Column(String, primary_key=True, index=True)
    status = Column(String)
    reasoning = Column(Text)
    confidence = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)
    order_id = Column(String, index=True)