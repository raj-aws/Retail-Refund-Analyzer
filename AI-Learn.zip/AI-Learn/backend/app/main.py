from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from app.nodes.order_lookup import get_order
import uuid
import time
from app.tools.orders_api import get_order
from app.utils.logger import logger
from app.graph.builder import build_graph
from app.db.database import SessionLocal
from app.db.models import Ticket
from app.nodes.action import action_node

app = FastAPI()

app.mount("/static", StaticFiles(directory="app/static"), name="static")

graph = build_graph()
templates = Jinja2Templates(directory="app/templates")


# -------------------------------------------------
# Middleware
# -------------------------------------------------
@app.middleware("http")
async def log_requests(request: Request, call_next):
    start_time = time.time()
    logger.info(f"Incoming request: {request.method} {request.url}")

    try:
        response = await call_next(request)
    except Exception:
        logger.exception("Unhandled Exception:")
        raise

    process_time = round(time.time() - start_time, 3)
    logger.info(f"Completed in {process_time}s with status {response.status_code}")

    return response


# -------------------------------------------------
# Home Page
# -------------------------------------------------
@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


# -------------------------------------------------
# Submit Ticket (Evaluation Phase)
# -------------------------------------------------
@app.post("/submit", response_class=HTMLResponse)
def submit_ticket(
    request: Request,
    text: str = Form(...),
    order_id: str = Form(...),
    customer_id: str = Form(...)
):

    ticket_id = str(uuid.uuid4())
    logger.info("Invoking evaluation graph...")

    try:
        state = graph.invoke({
            "ticket": {
                "ticket_id": ticket_id,
                "text": text,
                "order_id": order_id,
                "customer_id": customer_id
            },
            "order": None,
            "fraud": {},
            "retrieved_docs": [],
            "reasoning": "",
            "confidence": 0,
            "status": ""
        })

        logger.info(f"FINAL STATE: {state}")

    except Exception:
        logger.exception("Graph execution failed")
        return HTMLResponse(
            content="<h2>Internal Server Error - Check logs</h2>",
            status_code=500
        )

    result_view = {
        "decision": state.get("decision"),
        "status": state.get("status"),
        "confidence": state.get("confidence"),
        "reasoning": state.get("reasoning"),
        "applied_policy": state.get("applied_policy"),
        "decision_logic": state.get("decision_logic"),
        "outcome_summary": state.get("outcome_summary"),
        "citations": state.get("citations"),
        "allowed_window_days": state.get("allowed_window_days"),
        "action_result": state.get("action_result"),
        "retrieved_docs": state.get("retrieved_docs"),
        "policy_diff": state.get("policy_diff"),
    }

    # Save minimal ticket record
    try:
        db = SessionLocal()
        db_ticket = Ticket(
            id=ticket_id,
            order_id=order_id,
            status=result_view.get("status"),
            reasoning=result_view.get("reasoning"),
            confidence=result_view.get("confidence")
        )
        db.add(db_ticket)
        db.commit()
    except Exception:
        logger.exception("Database save failed")
    finally:
        db.close()

    return templates.TemplateResponse(
        "review.html",
        {
            "request": request,
            "ticket_id": ticket_id,
            "result": result_view
        }
    )


# -------------------------------------------------
# Approve (Execution Phase Only)
# -------------------------------------------------
# -------------------------------------------------
# Approve (Execution Phase Only)
# -------------------------------------------------
@app.post("/approve/{ticket_id}", response_class=HTMLResponse)
def approve(ticket_id: str, request: Request):

    db = SessionLocal()
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()

    

    if not ticket:
        db.close()
        return RedirectResponse("/", status_code=303)

    # ✅ Extract values BEFORE closing session
    ticket_reasoning = ticket.reasoning
    ticket_confidence = ticket.confidence
    order = get_order(ticket.order_id)

    if not order:
        return HTMLResponse("Order not found", status_code=400)

    state = {
        "decision": "AUTO_APPROVED_REFUND",
        "status": "APPROVED_BY_HUMAN",
        "order": order,
        "reasoning": ticket_reasoning
    }


    state = action_node(state)

    # Update DB with execution status
    ticket.status = state.get("status")
    db.commit()
    db.close()

    # 🔴 If payment failed → show failure page
    # If payment failed → show failure page
    if state.get("status") == "PAYMENT_FAILED":
        return templates.TemplateResponse(
            "payment_failure.html",
            {
               "request": request,
               "ticket_id": ticket_id,
               "amount": state.get("action_result", {}).get("amount", 0)
            }
        )

    # If success → show simple success page
    return templates.TemplateResponse(
        "payment_success.html",
        {
            "request": request,
            "ticket_id": ticket_id,
            "amount": state.get("action_result", {}).get("amount", 0)
        }
    )
    


# -------------------------------------------------
# Retry Payment
# -------------------------------------------------
# -------------------------------------------------
# Retry Payment
# -------------------------------------------------
@app.post("/retry/{ticket_id}", response_class=HTMLResponse)
def retry_payment(ticket_id: str, request: Request):

    db = SessionLocal()
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()

    if not ticket:
        db.close()
        return RedirectResponse("/", status_code=303)

    ticket_reasoning = ticket.reasoning
    ticket_confidence = ticket.confidence

    order = get_order(ticket_id)

    order = get_order(ticket.order_id)

    if not order:
        logger.error("Order not found during execution")
        return HTMLResponse("Order not found", status_code=400)

    state = {
        "status": "APPROVED_BY_HUMAN",
        "order": order,
        "reasoning": ticket_reasoning
    }

    state = action_node(state)

    ticket.status = state.get("status")
    db.commit()
    db.close()

    if state.get("status") == "PAYMENT_FAILED":
        return templates.TemplateResponse(
            "payment_failure.html",
            {
                "request": request,
                "ticket_id": ticket_id,
                "amount": state.get("action_result", {}).get("amount", 0)
            }
        )

    return templates.TemplateResponse(
        "review.html",
        {
            "request": request,
            "ticket_id": ticket_id,
            "result": {
                "decision": "AUTO_APPROVED_REFUND",
                "status": state.get("status"),
                "confidence": ticket_confidence,
                "reasoning": ticket_reasoning,
                "applied_policy": "Retained from evaluation",
                "decision_logic": "",
                "outcome_summary": "",
                "citations": [],
                "allowed_window_days": "",
                "action_result": state.get("action_result"),
                "retrieved_docs": None,
                "policy_diff": None
            }
        }
    )


# -------------------------------------------------
# Cancel Refund
# -------------------------------------------------
@app.post("/cancel/{ticket_id}")
def cancel_payment(ticket_id: str):

    db = SessionLocal()
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()

    if ticket:
        ticket.status = "CANCELLED_BY_HUMAN"
        db.commit()

    db.close()

    return RedirectResponse("/", status_code=303)


# -------------------------------------------------
# Reject (HITL)
# -------------------------------------------------
@app.post("/reject/{ticket_id}")
def reject(ticket_id: str):

    db = SessionLocal()
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()

    if ticket:
        ticket.status = "REJECTED_BY_HUMAN"
        db.commit()

    db.close()

    return RedirectResponse("/", status_code=303)


# -------------------------------------------------
# Edit Decision (HITL)
# -------------------------------------------------
@app.post("/edit/{ticket_id}")
def edit_decision(
    ticket_id: str,
    decision: str = Form(...),
    status: str = Form(...),
    reasoning: str = Form(...)
):

    db = SessionLocal()
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()

    if ticket:
        ticket.status = status
        ticket.reasoning = f"Edited by human:\n\n{reasoning}"
        db.commit()

    db.close()

    return RedirectResponse("/", status_code=303)