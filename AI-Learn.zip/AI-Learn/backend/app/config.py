import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# -----------------------------------
# Base Directory
# -----------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# -----------------------------------
# Database
# -----------------------------------
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://postgres:password@localhost/omni_copilot"
)

# -----------------------------------
# Paths
# -----------------------------------
ASSETS_PATH = os.path.join(BASE_DIR, "assets")
DOCS_PATH = os.path.join(ASSETS_PATH, "docs")
DATA_PATH = os.path.join(ASSETS_PATH, "data")
TICKETS_PATH = os.path.join(ASSETS_PATH, "tickets")
FRAUD_HITL_THRESHOLD = 0.7

# Chroma DB directory (USED BY retrieval)
CHROMA_DIR = os.getenv(
    "CHROMA_DIR",
    os.path.join(BASE_DIR, "chroma_db")
)

# -----------------------------------
# LLM Configuration
# -----------------------------------
LLM_MODEL = os.getenv(
    "LLM_MODEL",
    "llama3:8b-instruct-q4_K_M"
)

# -----------------------------------
# Business Rules
# -----------------------------------
CONFIDENCE_THRESHOLD = float(
    os.getenv("CONFIDENCE_THRESHOLD", 0.75)
)