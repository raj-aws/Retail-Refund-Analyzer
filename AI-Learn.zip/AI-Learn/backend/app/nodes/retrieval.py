from app.utils.logger import logger
from app.rag.chroma_store import get_relevant_docs


def retrieval_node(state):
    logger.info("Retrieval node started")

    query = state["ticket"]["text"]

    docs = get_relevant_docs(query, k=5)

    structured_docs = []
    context_chunks = []

    for doc in docs:
       metadata = doc.get("metadata", {})

       structured_doc = {
           "content": doc.get("content"),
           "source": metadata.get("source"),
           "version": metadata.get("version"),
           "effective_date": metadata.get("effective_date"),
           "policy_type": metadata.get("policy_type"),
           "chunk_id": metadata.get("chunk_id")
       }

       structured_docs.append(structured_doc)
       context_chunks.append(doc.get("content"))

            

    # ✅ Structured docs (for diff + UI)
    state["retrieved_docs"] = structured_docs

    # ✅ Plain text context (for policy enforcement prompt)
    state["retrieval_context"] = "\n\n".join(context_chunks)

    logger.info(f"Retrieved {len(structured_docs)} documents")

    return state