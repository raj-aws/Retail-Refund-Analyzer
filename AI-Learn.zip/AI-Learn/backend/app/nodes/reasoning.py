from app.utils.logger import logger
from app.config import LLM_MODEL
from langchain_ollama import OllamaLLM

llm = OllamaLLM(model=LLM_MODEL)


def reasoning_node(state):
    logger.info("Reasoning node started")

    context = "\n\n".join(state.get("retrieved_docs", []))

    prompt = f"""
    Provide policy-grounded explanation.

    Context:
    {context}

    Deterministic Decision:
    {state['decision']}

    Ticket:
    {state['ticket']['text']}
    """

    result = llm.invoke(prompt)

    state["reasoning"] = result
    return state