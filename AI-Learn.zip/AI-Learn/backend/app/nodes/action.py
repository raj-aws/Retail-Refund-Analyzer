from app.utils.logger import logger
from app.tools.payments_api import create_refund, PaymentTimeout
from app.utils.retry import retry_with_backoff


def action_node(state):

    logger.info("Action node started")

    decision = state.get("decision")
    status = state.get("status")

    # Only run payment for approved scenarios
    if decision not in ["AUTO_APPROVED_REFUND"] and status != "APPROVED_BY_HUMAN":
        return state

    order = state.get("order")

    if not order:
        state["status"] = "ERROR_NO_ORDER"
        state["reasoning"] += "\nOrder missing during execution."
        return state

    amount = order["price"]

    # -----------------------------------------
    # AUTO APPROVED REFUND → ALWAYS SUCCESS
    # -----------------------------------------
    if decision == "AUTO_APPROVED_REFUND":

        logger.info("Auto approved refund → executing payment")

        state["action_result"] = {
            "status": "SUCCESS",
            "amount": amount
        }

        state["status"] = "ACTION_EXECUTED"

        return state

    # -----------------------------------------
    # HUMAN APPROVED → CALL PAYMENT API
    # -----------------------------------------
    try:

        logger.info("Human approved refund → calling payment API")

        result = retry_with_backoff(
            lambda: create_refund(amount),
            retries=3,
            base_delay=1
        )

        state["action_result"] = result
        state["status"] = "ACTION_EXECUTED"

        return state

    except PaymentTimeout:

        logger.error("Payment API failed after retries")

        state["status"] = "PAYMENT_FAILED"
        state["decision"] = "PAYMENT_API_FAILURE"

        state["action_result"] = {
            "status": "FAILED_TIMEOUT",
            "amount": amount
        }

        return state