from app.utils.logger import logger
from app.config import FRAUD_HITL_THRESHOLD


def safety_node(state):
    logger.info("Safety node started")

    fraud_score = state.get("fraud_score", 0)
    fraud_flags = state.get("fraud_flags", [])

    logger.info(f"Fraud score in safety: {fraud_score}")

    if fraud_score >= FRAUD_HITL_THRESHOLD:
        logger.info("Fraud threshold exceeded — overriding decision")

        # 🔴 Override decision explicitly
        state["decision"] = "FRAUD_BASED_TRANSACTION"

        # 🔴 Force HITL
        state["status"] = "PENDING_HUMAN_REVIEW"

        state["reasoning"] += (
            f"\n\nFraud Risk Assessment:\n"
            f"- Fraud score: {fraud_score}\n"
            f"- Flags: {', '.join(fraud_flags)}\n"
            f"- Supervisor review required before refund execution."
        )

    return state