from app.utils.logger import logger
def hitl_node(state):
    logger.info("Hitl node started")
    logger.info(f"hitl result: {state['ticket']}")
    return state