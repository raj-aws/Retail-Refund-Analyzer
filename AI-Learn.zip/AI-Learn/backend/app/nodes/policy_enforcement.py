from datetime import datetime
import re
from langchain_ollama import OllamaLLM
from app.config import LLM_MODEL
from app.utils.logger import logger
from app.tools.json_parser import extract_json_from_response
from app.utils.policy_diff import generate_diff

llm = OllamaLLM(model=LLM_MODEL, temperature=0)


# ------------------------------------------------
# Extract Premium Threshold from Policy Content
# ------------------------------------------------
def extract_premium_threshold(retrieved_docs):
    for doc in retrieved_docs:
        content = doc.get("content", "")
        match = re.search(r"price\s*>=\s*(\d+)", content)
        if match:
            return float(match.group(1))
    return None


def policy_enforcement_node(state):
    logger.info("PolicyEnforcement (Structured) started")

    order = state.get("order")
    retrieved_docs = state.get("retrieved_docs", [])
    context = state.get("retrieval_context", "")

    # ------------------------------------------------
    # Basic Guards
    # ------------------------------------------------
    if not order:
        state["decision"] = "INVALID_ORDER"
        state["status"] = "PENDING_HUMAN_REVIEW"
        state["reasoning"] = "Order not found."
        return state

    if not retrieved_docs:
        state["decision"] = "REQUIRES_REVIEW"
        state["status"] = "PENDING_HUMAN_REVIEW"
        state["reasoning"] = "No policy documents retrieved."
        return state

    # ------------------------------------------------
    # Controlled Policy Diff (version-aware)
    # ------------------------------------------------
    policies = {}
    logger.info("Retrieved docs for threshold scan:")
    for doc in retrieved_docs:
        logger.info(f"document content is {doc.get('content')}")
        policy_type = doc.get("policy_type")
        if policy_type:
            policies.setdefault(policy_type, []).append(doc)

            logger.info("Retrieved docs for threshold scan:")


    for policy_type, versions in policies.items():
        if len(versions) >= 2:
            versions = sorted(
                versions,
                key=lambda x: x.get("effective_date", "1900-01-01")
            )
            older = versions[0]["content"]
            newer = versions[-1]["content"]
            state["policy_diff"] = generate_diff(older, newer)
            break

    # ------------------------------------------------
    # LLM Prompt
    # ------------------------------------------------
    prompt = f"""
You are a strict policy decision engine.

Use ONLY the policy documents in the context below.

Rules:
- Category-specific overrides general policy.
- Newer version overrides older version.
- Effective date must be respected.
- Ensure allowed_window_days matches the policy used in decision_logic.
- Do not mix policies.

Context:
{context}

Order Data:
- SKU: {order.get("sku")}
- Purchase Date: {order.get("purchase_date")}
- Price: {order.get("price")}
- Customer Request: {state["ticket"]["text"]}

Today Date: {datetime.now().strftime("%Y-%m-%d")}

Return STRICT JSON ONLY.

{{
    "applied_policy": "",
    "allowed_window_days": 0,
    "decision": "APPROVED or DENIED",
    "citations": [
        {{
            "clause": "",
            "excerpt": ""
        }}
    ],
    "decision_logic": "",
    "outcome_summary": ""
}}
"""

    # ------------------------------------------------
    # LLM Invocation + Retry
    # ------------------------------------------------
    response = llm.invoke(prompt)
    result = extract_json_from_response(response)

    if not result:
        logger.warning("Retrying JSON enforcement...")
        retry_prompt = prompt + "\n\nIMPORTANT: Respond with VALID JSON only. No explanations."
        response = llm.invoke(retry_prompt)
        result = extract_json_from_response(response)

    if not result:
        state["decision"] = "REQUIRES_REVIEW"
        state["status"] = "PENDING_HUMAN_REVIEW"
        state["reasoning"] = "Policy engine failed to return structured JSON."
        return state

    logger.info(f"LLM Raw Response: {response}")

    # ------------------------------------------------
    # Validate Required Fields
    # ------------------------------------------------
    required_keys = [
        "applied_policy",
        "allowed_window_days",
        "decision",
        "citations",
        "decision_logic",
        "outcome_summary"
    ]

    if not all(k in result for k in required_keys):
        state["decision"] = "REQUIRES_REVIEW"
        state["status"] = "PENDING_HUMAN_REVIEW"
        state["reasoning"] = "Incomplete structured policy response."
        return state

    # ------------------------------------------------
    # Assign Structured Fields
    # ------------------------------------------------
    state["applied_policy"] = result["applied_policy"]
    state["allowed_window_days"] = result["allowed_window_days"]
    state["decision_logic"] = result["decision_logic"]
    state["outcome_summary"] = result["outcome_summary"]

    # Normalize citations
    raw_citations = result.get("citations", [])
    normalized_citations = []

    for c in raw_citations:
        if isinstance(c, dict):
            normalized_citations.append({
                "clause": c.get("clause", ""),
                "excerpt": c.get("excerpt", "")
            })
        else:
            normalized_citations.append({
                "clause": "",
                "excerpt": str(c)
            })

    state["citations"] = normalized_citations

    # ------------------------------------------------
    # Decision Mapping
    # ------------------------------------------------
    decision_value = result["decision"].strip().upper()

    if decision_value not in ["APPROVED", "DENIED"]:
        state["decision"] = "REQUIRES_REVIEW"
        state["status"] = "PENDING_HUMAN_REVIEW"
        state["reasoning"] = "Invalid decision value from policy engine."
        return state

    if decision_value == "APPROVED":
        state["decision"] = "AUTO_APPROVED_REFUND"
        state["status"] = "AUTO_APPROVED"
    else:
        state["decision"] = "RETURN_WINDOW_EXPIRED"
        state["status"] = "DENIED"

    # ------------------------------------------------
    # Deterministic Premium Threshold Enforcement
    # ------------------------------------------------
    threshold = extract_premium_threshold(retrieved_docs)
    price = float(order.get("price", 0))

    if threshold and price >= threshold:
        state["decision"] = "REPAIR_OR_REPLACE"
        state["status"] = "PENDING_HUMAN_REVIEW"
        state["reasoning"] += (
            f"\n\nPremium threshold ({threshold}) exceeded. "
            "Repair/Replace workflow recommended. Supervisor approval required."
        )

    # ------------------------------------------------
    # Structured Reasoning Block
    # ------------------------------------------------
    state["reasoning"] = (
        f"Policy Applied: {state['applied_policy']}\n\n"
        f"Decision Logic:\n{state['decision_logic']}\n\n"
        f"Outcome:\n{state['outcome_summary']}\n\n"
        f"{state['reasoning']}"
    )

    return state