from app.tools.fraud_lookup import get_fraud
from app.utils.logger import logger


def fraud_lookup_node(state):
    logger.info("FraudLookup node started")

    customer_id = state["ticket"].get("customer_id")

    fraud_data = get_fraud(customer_id)

    if not fraud_data:
        state["fraud_score"] = 0
        state["fraud_flags"] = []
        return state

    # Score is already normalized inside get_fraud()
    fraud_score = fraud_data.get("score", 0)
    flags_raw = fraud_data.get("flags", "")

    flags = flags_raw.split(";") if isinstance(flags_raw, str) else flags_raw

    state["fraud_score"] = fraud_score
    state["fraud_flags"] = flags

    logger.info(f"Fraud score: {fraud_score}")
    logger.info(f"Fraud flags: {flags}")

    return state