from app.utils.logger import logger
def intent_node(state):
    logger.info("Intent node started")

    text = state["ticket"]["text"].lower()

    if "refund" in text or "return" in text:
        state["ticket"]["intent"] = "refund"
    elif "repair" in text:
        state["ticket"]["intent"] = "repair"
    else:
        state["ticket"]["intent"] = "info"
    logger.info(f"Intent detected: {state['ticket']['intent']}")
    return state