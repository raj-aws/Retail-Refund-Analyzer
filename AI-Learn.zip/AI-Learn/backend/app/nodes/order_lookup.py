from app.tools.orders_api import get_order
from app.utils.logger import logger


def order_lookup_node(state):
    logger.info("OrderLookup node started")

    order_id = state["ticket"].get("order_id")

    if not order_id:
        state["decision"] = "INVALID_ORDER"
        state["status"] = "PENDING_HUMAN_REVIEW"
        state["reasoning"] = "Order ID not provided."
        return state

    order = get_order(order_id)
    state["order"] = order

    logger.info(f"order result: {order}")

    if not order:
        state["decision"] = "INVALID_ORDER"
        state["status"] = "PENDING_HUMAN_REVIEW"
        state["reasoning"] = "Order ID not found in order database."
        return state

    return state