from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from app.config import CHROMA_DIR

embedding_model = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

vector_store = Chroma(
    persist_directory=CHROMA_DIR,
    embedding_function=embedding_model,
    collection_name="policy_docs"
)


def get_relevant_docs(query, k=3):
    docs = vector_store.similarity_search(query, k=k)

    structured_docs = []

    for doc in docs:
        structured_docs.append({
            "content": doc.page_content,
            "metadata": doc.metadata or {}
        })

    return structured_docs