import pandas as pd
import os
from app.config import DATA_PATH

orders_df = pd.read_csv(os.path.join(DATA_PATH, "orders.csv"))
fraud_df = pd.read_csv(os.path.join(DATA_PATH, "fraud_markers.csv"))
catalog_df = pd.read_csv(os.path.join(DATA_PATH, "product_catalog.csv"))