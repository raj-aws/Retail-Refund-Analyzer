import os
import re
from datetime import datetime
from sentence_transformers import SentenceTransformer
import chromadb
from app.config import DOCS_PATH, CHROMA_DIR


class MarkdownIngestor:

    def __init__(self):
        self.embedder = SentenceTransformer("all-MiniLM-L6-v2")
        self.client = chromadb.PersistentClient(path=CHROMA_DIR)
        self.collection = self.client.get_or_create_collection("policy_docs")

    # ----------------------------------------
    # Extract metadata from filename
    # ----------------------------------------
    def extract_metadata(self, filename: str):

        name = filename.lower()

        # Determine policy type
        if "addendum" in name or "electronics" in name:
            policy_type = "electronics"
        elif "return" in name:
            policy_type = "returns"
        elif "warranty" in name:
            policy_type = "warranty"
        else:
            policy_type = "general"

        # Extract version (vX or vX_Y pattern)
        version_match = re.search(r"v(\d+(_\d+)*)", name)
        version = version_match.group(0) if version_match else "unknown"

        # Try to extract effective date (YYYY-MM-DD)
        date_match = re.search(r"\d{4}-\d{2}-\d{2}", name)
        effective_date = date_match.group(0) if date_match else "1900-01-01"

        return {
            "source": filename,
            "policy_type": policy_type,
            "version": version,
            "effective_date": effective_date
        }

    # ----------------------------------------
    # Ingest Documents
    # ----------------------------------------
    def ingest(self):

        if self.collection.count() > 0:
            return

        for root, _, files in os.walk(DOCS_PATH):
            for file in files:
                if file.endswith(".md"):
                    path = os.path.join(root, file)

                    with open(path, "r", encoding="utf-8") as f:
                        content = f.read()

                    metadata_base = self.extract_metadata(file)

                    chunks = [
                        content[i:i + 800]
                        for i in range(0, len(content), 800)
                    ]

                    embeddings = self.embedder.encode(chunks).tolist()

                    for i, chunk in enumerate(chunks):
                        metadata = metadata_base.copy()
                        metadata["chunk_id"] = i

                        self.collection.add(
                            documents=[chunk],
                            embeddings=[embeddings[i]],
                            metadatas=[metadata],
                            ids=[f"{file}_{i}"]
                        )

if __name__ == "__main__":
    MarkdownIngestor().ingest()