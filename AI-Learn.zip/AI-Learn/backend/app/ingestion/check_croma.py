from app.rag.chroma_store import vector_store

from app.config import CHROMA_DIR
print(CHROMA_DIR)

print("Checking Chroma DB...")


print("Collection name:", vector_store._collection.name)
print("Count:", vector_store._collection.count())
# Get collection size
collection = vector_store._collection

count = collection.count()

print(f"Number of documents in Chroma: {count}")

if count > 0:
    docs = vector_store.similarity_search("return policy", k=2)
    for i, doc in enumerate(docs):
        print(f"\nDoc {i+1}:\n{doc.page_content[:300]}")

    
"""
from chromadb import Client
from chromadb.config import Settings
from app.config import CHROMA_DIR

client = Client(Settings(
    persist_directory=CHROMA_DIR,
    is_persistent=True
))

collections = client.list_collections()

print("Available collections:")
for c in collections:
    print(c.name)

        """