from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.document_loaders import DirectoryLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter

from app.config import DOCS_PATH, CHROMA_DIR

print("Loading documents from:", DOCS_PATH)

loader = DirectoryLoader(DOCS_PATH, glob="**/*.md")
documents = loader.load()

print(f"Loaded {len(documents)} documents")

text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200
)

docs = text_splitter.split_documents(documents)

print(f"Split into {len(docs)} chunks")

embedding_model = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

print("Creating Chroma DB...")

vector_store = Chroma.from_documents(
    docs,
    embedding_model,
    persist_directory=CHROMA_DIR,
    collection_name="policy_docs"
)

vector_store.persist()

print("Chroma DB built successfully.")