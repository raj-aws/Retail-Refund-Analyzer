# Email Templates

## Variables

Common placeholders:

- `{{customer_name}}`
- `{{order_id}}`
- `{{sku}}`
- `{{amount}}`
- `{{policy_ref}}`
- `{{eta}}`

## TEMPLATE_RETURN_APPROVED

Subject: Your return request is approved

Body:
Hi {{customer_name}},

Your return for order {{order_id}} has been approved.
Refund amount: {{amount}}.
Estimated posting time: {{eta}}.

Reference: {{policy_ref}}

Thank you,
OmniRetail Support

## TEMPLATE_REPLACEMENT_OFFERED

Subject: Replacement option for your reported issue

Body:
Hi {{customer_name}},

Based on our review, we can offer a replacement for SKU {{sku}}.
Next step: please confirm your shipping address and we’ll proceed.

Reference: {{policy_ref}}

Thank you,
OmniRetail Support

## TEMPLATE_HITL_REVIEW

Subject: Your request needs specialist review

Body:
Hi {{customer_name}},

Your request is currently under specialist review to ensure the best possible resolution.
We’ll update you within 1 business day.

Thank you for your patience,
OmniRetail Support

## TEMPLATE_RETURN_DENIED

Subject: Update on your return request

Body:
Hi {{customer_name}},

After review, we’re unable to approve this return under current policy.
Reason: {{policy_ref}}.

If you’d like, we can help with alternative options (repair, support, or store credit where applicable).

Thank you,
OmniRetail Support

## TEMPLATE_MANUAL_ACTION_DELAY

Subject: Your request is approved and pending manual completion

Body:
Hi {{customer_name}},

Your request has been approved, but final processing is delayed due to a temporary system issue.
Our team is completing this manually. Expected update: {{eta}}.

Thank you,
OmniRetail Support
