# Electronics Troubleshooting Guide (Top Issues)

## Usage Notes

- Run steps in order unless safety risk is present.
- Capture results for each step in ticket notes.
- If customer cannot perform step safely, skip and escalate.

## Device will not power on

1. Confirm charger and cable compatibility.
2. Hold power button for 12 seconds.
3. Try alternate power outlet.
4. Run diagnostic mode if supported.

If unresolved after steps, classify as `suspected_hardware_defect`.

Evidence to request:

- Indicator LED behavior (none/blink/solid)
- Charger model and wattage
- Short video showing attempted power-on

## Overheating

1. Verify ventilation and ambient temperature.
2. Check firmware version and update if available.
3. Disable high-performance mode.

If persistent, route to warranty diagnostic flow.

Escalate immediately if:

- device temperature causes shutdown repeatedly within 10 minutes,
- battery swelling or unusual odor is reported,
- burn marks are visible.

## Display artifacts/flicker

1. Test with factory reset profile.
2. Check cable/connector seating.
3. Capture photo/video evidence for support record.

If issue reproduces in safe mode and on external display test, classify as display subsystem defect.

## Connectivity Failure (Wi-Fi/Bluetooth)

1. Reset network stack.
2. Forget/re-pair devices.
3. Confirm latest firmware.
4. Test against alternate router/accessory.

If issue persists across multiple networks/devices, route to hardware radio diagnostic.

## Troubleshooting Outcome Codes

- `TS-RESOLVED` — issue resolved during guided steps
- `TS-SW-ISSUE` — software/configuration issue
- `TS-HW-SUSPECTED` — likely hardware defect
- `TS-SAFETY-ESC` — safety escalation required
