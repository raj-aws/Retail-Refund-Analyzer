# OmniRetail Category Addendum: Electronics v3.2

- **policy_id:** `RET-ELEC-V3.2`
- **effective_date:** `2025-01-01`
- **last_updated:** `2025-01-15`
- **owner:** Electronics Category Operations
- **review_cycle:** monthly
- **category:** electronics
- **supersedes:** `RET-V3` where rules conflict for electronics

## Electronics Return Window

For orders in category `electronics` with purchase date on or after `2025-01-01`, return window is **45 calendar days**.

## Scope Clarification

- Applies to: consumer electronics, accessories, smart home electronics.
- Excludes: enterprise/B2B custom-configured devices unless account contract states otherwise.
- For mixed carts, evaluate each line item independently by SKU category.

## Condition Handling

- Open-box electronics are eligible if accessories are substantially complete.
- Verified defects may be routed to replacement or warranty repair.
- Missing charger/cable may reduce refund amount based on replacement accessory cost.
- Device account lock (e.g., activation lock) must be removed before return acceptance.

## Defect Routing

- Within return window and low value: refund or replacement based on customer preference.
- Beyond return window but within warranty: route to warranty repair/replacement.
- Safety-related defect (battery swelling, smoke, electrical risk): immediate escalation and shipping hold protocol.

## Decision Matrix (Electronics)

| Scenario | Recommended Outcome |
|---|---|
| Non-defect, <=45 days, complete item | Refund or store credit |
| Non-defect, >45 days | Deny return; offer support exception path |
| Defect, <=45 days, stock available | Replacement preferred |
| Defect, >45 days and within warranty | Repair workflow |

## Decision Precedence

When electronics addendum conflicts with general returns policy, use this addendum.

## Citation Guidance for AI Systems

When generating customer-facing rationale, cite this addendum and include:

1. Applicable return window clause.
2. Defect/non-defect branch.
3. Any accessory or condition adjustments.
