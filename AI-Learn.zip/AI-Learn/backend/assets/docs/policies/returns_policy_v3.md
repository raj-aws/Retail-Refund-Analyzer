# OmniRetail Returns Policy v3.0

- **policy_id:** `RET-V3`
- **effective_date:** `2024-06-01`
- **last_updated:** `2025-04-01`
- **owner:** Retail Operations Policy Council
- **review_cycle:** quarterly
- **scope:** all categories unless superseded by newer, category-specific addendum

## Purpose

This policy defines baseline eligibility, allowed resolutions, and guardrails for customer-initiated returns across all channels (online, store, marketplace-fulfilled where OmniRetail is seller of record).

## Standard Return Eligibility

1. Returns are eligible within **30 calendar days** of purchase date.
2. Item must be in returnable condition unless defect is verified.
3. Proof of purchase is required (order id, receipt, or verified account lookup).
4. Return window is calculated using local store timezone for in-store purchases and UTC order timestamp for online purchases.

## Condition Grades

- **Grade A (new/unopened):** full refund eligible.
- **Grade B (opened, complete accessories):** refund eligible; possible restocking fee if configured by category.
- **Grade C (missing accessories/minor wear):** agent discretion for partial refund or store credit.
- **Grade D (damage from misuse):** not eligible unless covered under explicit warranty extension.

## Resolution Types

- Refund to original payment method
- Store credit
- Replacement when stock is available

Resolution should prioritize customer intent when policy allows. If customer requests replacement and replacement stock is unavailable, fallback to refund/store credit.

## SLA Targets

- Initial triage decision: within 15 minutes of ticket creation.
- Action completion after approval: within 1 business hour.
- Customer communication: always include decision reason and next steps.

## Exclusions

- Final-sale SKUs are non-returnable unless defective.
- Damage from misuse is not eligible for return/refund.
- Consumables with broken hygiene seal are non-returnable unless defective.
- Gift cards and digital-only subscriptions are non-refundable after redemption/activation.

## Required Evidence

- Order reference (order id, email + postal code, or payment token suffix).
- For defect claims: at least one of photo, video, or troubleshooting log.
- For high-value items: serial number match to order record.

## Conflict Rule

If a category addendum is newer and more specific than this policy, the addendum supersedes this policy for that category.

## Version Precedence Rules

1. Category-specific addendum overrides base policy when both apply.
2. Newer effective date overrides older effective date for same scope.
3. If two policies are equally specific and date-equal, use policy with higher semantic version.
4. If unresolved, escalate to human reviewer with both clauses attached.

## Examples

- Apparel item at day 20, unopened: approve refund under base policy.
- Electronics item at day 35 (purchase after 2025-01-01): defer to electronics addendum.
- Final-sale item with no defect evidence: deny refund, offer goodwill coupon if SOP permits.
