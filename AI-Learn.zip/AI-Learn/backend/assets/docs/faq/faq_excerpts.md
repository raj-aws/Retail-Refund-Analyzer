# FAQ Excerpts

## Q: How long do returns take?

Refunds typically post in 3-7 business days after return is approved and scanned by carrier.

## Q: Do I pay for return shipping?

For non-defect returns, shipping may be deducted where policy permits. For verified defects, return shipping is waived.

## Q: What if my product is defective?

Defective items may be repaired, replaced, or refunded based on warranty terms, diagnostics, and value thresholds.

## Q: Can I get a refund instead of repair?

For premium electronics and certain warranty cases, repair or replacement is prioritized. Refund may require supervisor approval.

## Q: Can I return electronics after 30 days?

Some electronics may have extended windows under category-specific addenda. Latest applicable policy version should be used.

## Q: What information should I provide in my request?

Please include order id, item sku, issue summary, and any photos/videos if reporting a defect.

## Q: Why was my case sent for specialist review?

Cases may be reviewed for policy conflicts, high-value actions, fraud-risk indicators, or system/tool errors.
