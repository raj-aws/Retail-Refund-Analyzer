# Electronics Warranty Addendum v1.1

- **warranty_id:** `WAR-ELEC-V1.1`
- **effective_date:** `2025-02-01`
- **last_updated:** `2025-06-01`
- **owner:** Electronics Warranty Team
- **category:** electronics

## Extended Electronics Handling

- Premium electronics (`price >= 1000`) should prefer **diagnostic + repair/replace** workflow before refund.
- If defect is confirmed within warranty period and replacement stock exists, replacement is allowed.
- Refund for premium electronics requires supervisor approval.

## Premium Device Requirements

- Serial number must match order record before final decision.
- If tamper indicators are present, require specialist review.
- For data-bearing devices, confirm customer data backup and wipe instructions before RMA handoff.

## Triage Outcomes

- **Confirmed hardware defect + parts available:** repair path.
- **Confirmed hardware defect + no parts + stock available:** replacement path.
- **No reproducible defect:** return to customer with troubleshooting report.
- **Safety critical defect:** immediate escalation and expedited replacement consideration.

## Approval Thresholds

- Any premium electronics refund must include explicit human approval.
- Repeat premium claims by same customer within 90 days require fraud review check.

## Documentation for Decision Logs

- Defect classification
- Diagnostic result id
- Selected remedy and reason
- Estimated cost and turnaround
