# OmniRetail Base Warranty Terms v2.0

- **warranty_id:** `WAR-BASE-V2`
- **effective_date:** `2024-01-01`
- **last_updated:** `2025-03-10`
- **owner:** Warranty Program Office

## Coverage

- Manufacturer defects and hardware failure under normal use.
- Standard coverage period: **12 months** from purchase date.
- Labor and standard replacement parts are included for covered repairs.

## Warranty Start and End

- Start date: recorded purchase date in order system.
- End date: 12 months later at 23:59 local timezone of purchase channel.
- If purchase date is disputed, use first verifiable proof in this order: invoice, payment confirmation, shipment confirmation.

## Exclusions

- Cosmetic wear and tear.
- Accidental damage unless extended protection plan exists.
- Unauthorized repair attempts.
- Consumable degradation (e.g., battery wear within expected tolerance) unless out-of-spec per diagnostics.
- Software-only issues resolved by reinstall/update guidance.

## Remedies

- Repair (preferred when feasible)
- Replacement (if repair not feasible)
- Refund only when repair/replacement unavailable or policy-approved exception

## Service Flow

1. Validate purchase and warranty status.
2. Run category troubleshooting checklist.
3. Collect defect evidence and diagnostics outcome.
4. Select remedy and communicate turnaround time.

## Typical Timelines

- Remote diagnostics: same day.
- Depot repair: 5-10 business days.
- Replacement shipment: 2-5 business days after approval.

## Required Customer Inputs

- Order id or equivalent proof of purchase.
- Product serial number (if applicable).
- Defect description and reproduction steps.
- Photos/videos for physical issues when requested.
