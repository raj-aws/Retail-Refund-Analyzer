# Customer Service SOP (Returns & Warranty)

## Objectives

- Deliver consistent, policy-grounded decisions.
- Minimize fraud exposure while preserving customer trust.
- Ensure complete audit trail for all actions and overrides.

## Intake Checklist

1. Verify customer identity and order linkage.
2. Determine request intent: refund, replacement, repair, info.
3. Capture issue classification: non-defect, defect, potential abuse.
4. Pull latest applicable policy metadata and category addenda.

## Refund and Approval Rules

- Auto-approve low-risk refunds under **$250** when fully in policy.
- Supervisor approval required for any refund/replacement value **>= $1000**.
- Identity check required when account email and payment profile mismatch.

## Human-in-the-Loop Triggers

- Confidence score below configured threshold.
- Conflicting policy clauses with unresolved precedence.
- High-value action (`>= 1000`) or discretionary exception request.
- Fraud score threshold met or exceeded.
- External tool failure after retry policy exhausted.

## Fraud Controls

- Fraud score `>= 80` requires HITL review.
- Repeated returns in 90 days with high-value SKUs should be escalated.

## Communication Standards

- Explain decision in plain language.
- Include at least one policy rationale sentence.
- Provide next step and ETA.
- Avoid exposing internal fraud scoring details to customer-facing channels.

## Operational Fallbacks

- If payment API fails twice with exponential backoff, create manual review task.
- If order lookup is unavailable, request proof of purchase and route to human queue.

## Audit Logging Requirements

Every decision record must include:

- ticket_id, order_id, customer_id
- policy sources used (with versions)
- decision recommendation and confidence
- action payload summary
- reviewer decision if HITL occurred
