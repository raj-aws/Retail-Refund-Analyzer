# Mock Endpoints Reference

## Orders API

- `GET /orders/{orderId}`
- `GET /orders?email={email}`

## Payments API

- `POST /payments/refunds`
  - Business constraints (mock):
    - If `amount >= 1000` and `approved_by_human=false`, return 422.
    - If request payload includes `simulate_timeout=true`, emulate timeout.

## RMA / Logistics API

- `POST /rma/returns`

## Policy Service

- `GET /policy/latest`
