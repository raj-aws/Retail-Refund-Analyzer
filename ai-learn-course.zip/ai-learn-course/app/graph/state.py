from typing import TypedDict, Dict, List, Any, Optional


class AgentState(TypedDict):
    ticket: Dict[str, Any]
    order: Optional[Dict[str, Any]]
    fraud: Dict[str, Any]
    retrieved_docs: List[str]

    reasoning: str
    decision: str
    status: str
    confidence: float

    action_result: Optional[Dict[str, Any]]

    #  ADD THESE
    applied_policy: Optional[str]
    allowed_window_days: Optional[int]
    citations: Optional[List[Dict[str, str]]]
    decision_logic: Optional[str]
    outcome_summary: Optional[str]

    policy_diff: Optional[str]
    category: Optional[str]
    retrieval_context: Optional[str]

    fraud_score: Optional[float]
    fraud_flags: Optional[List[str]]
