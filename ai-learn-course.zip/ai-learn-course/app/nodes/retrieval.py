from app.utils.logger import logger
from app.rag.chroma_store import get_relevant_docs


def retrieval_node(state):
    logger.info(f"Retrieval node started {state.get('category')}")

    query = f"{state['ticket']['text']} category {state.get('category')}"
    logger.info(f"Retrieval query: {query}")
    docs = get_relevant_docs(query, k=5)

    structured_docs = []
    context_chunks = []

    for doc in docs:
       metadata = doc.get("metadata", {})
       logger.info(f"content: {doc.get("content")}")
       logger.info(f"content: {doc.get("source")}")
       logger.info(f"content: {doc.get("version")}")
       logger.info(f"content: {doc.get("effective_date")}")
       logger.info(f"content: {doc.get("policy_type")}")
       logger.info(f"content: {doc.get("chunk_id")}")
       structured_doc = {
           "content": doc.get("content"),
           "source": metadata.get("source"),
           "version": metadata.get("version"),
           "effective_date": metadata.get("effective_date"),
           "policy_type": metadata.get("policy_type"),
           "chunk_id": metadata.get("chunk_id")
       }

       structured_docs.append(structured_doc)
       context_chunks.append(doc.get("content"))

            

    #  Structured docs (for diff + UI)
    state["retrieved_docs"] = structured_docs

    #  Plain text context (for policy enforcement prompt)
    state["retrieval_context"] = "\n\n".join(context_chunks)
    logger.info(f"Retrived context : {state['retrieval_context']}")
    logger.info(f"Retrieved {len(structured_docs)} documents")

    return state