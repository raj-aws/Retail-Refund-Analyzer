from app.utils.logger import logger


def confidence_node(state):
    logger.info("Confidence node started")

    # Use normalized fraud_score directly
    fraud_score = float(state.get("fraud_score", 0.0))

    # Simple confidence logic
    confidence = 1.0 - fraud_score
    confidence = max(0.0, min(confidence, 1.0))

    state["confidence"] = round(confidence, 2)
    
    logger.info(f"Fraud score: {fraud_score}")
    logger.info(f"Calculated confidence: {state['confidence']}")

    # DO NOT modify status here anymore
    return state