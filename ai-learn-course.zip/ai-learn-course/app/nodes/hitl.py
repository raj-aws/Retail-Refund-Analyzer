from app.utils.logger import logger
def hitl_node(state):
    logger.info("Why it is not coming inside Hitl node started")
    logger.info(f"hitl result: {state['ticket']}")
    state["decision"] = "PENDING_HUMAN_REVIEW"
    state["status"] = "PENDING_HUMAN_REVIEW"
    return state