from app.utils.logger import logger
from app.tools.payments_api import create_refund, PaymentTimeout
from app.utils.retry import retry_with_backoff


def action_node(state):
    logger.info("Action node started")

    # Only execute if human approved or auto approved
    if state.get("status") not in ["AUTO_APPROVED", "APPROVED_BY_HUMAN"]:
        logger.info("Action skipped due to status")
        return state

    order = state.get("order")

    if not order:
        logger.error("Order missing during execution")
        state["status"] = "ERROR_NO_ORDER"
        state["reasoning"] = state.get("reasoning", "") + \
            "\n\nOrder missing during refund execution."
        return state

    amount = order.get("price")

    if amount is None:
        logger.error("Order price missing")
        state["status"] = "ERROR_NO_PRICE"
        state["reasoning"] = state.get("reasoning", "") + \
            "\n\nOrder price missing during refund execution."
        return state

    try:
        result = retry_with_backoff(
            lambda: create_refund(amount),
            retries=3,
            base_delay=1
        )

        logger.info("Payment succeeded")

        state["action_result"] = result
        state["status"] = "ACTION_EXECUTED"

        return state

    except Exception as e:
        # Catch ALL exceptions (important)
        logger.error(f"Payment execution failed: {str(e)}")

        state["status"] = "PAYMENT_FAILED"
        state["decision"] = "PAYMENT_API_FAILURE"

        state["action_result"] = {
            "status": "FAILED",
            "amount": amount
        }

        state["reasoning"] = state.get("reasoning", "") + (
            "\n\nPayment processing failed after retry attempts."
            "\nManual intervention required."
        )

        return state